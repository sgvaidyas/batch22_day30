﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day30_Dbfirst
{
    class Program
    {

        public static Product getProdDetails()
        {
            Product prod = new Product();
            Console.Write("Enter PID = ");
            prod.Pid = Convert.ToInt32(Console.ReadLine());
            Console.Write("\nEnter PNAME = ");
            prod.Pname = Console.ReadLine();
            Console.Write("\nEnter CID = ");
            prod.Cid = Convert.ToInt32(Console.ReadLine());
            Console.Write("\nEnter BTACHID = ");
            prod.batchId  = Convert.ToInt32(Console.ReadLine());
            return prod;
        }
        public static void display(Product p)
        {
            Console.WriteLine("{0}\t{1}\t{2}\t{3}\t{4}",p.Pid,p.Pname,p.Cid,p.batchId,p.Category.Cname);
        }
        static void Main(string[] args)
        {
            ProdMgmtEntities db = new ProdMgmtEntities();
            int choice,id;
            Product prod;
            do
            {
                Console.WriteLine("1 INSERT 2 Display 3 UPDATE 4 DELETE 5 EXIT");
                choice = Convert.ToInt32(Console.ReadLine());
                switch(choice)
                {
                    case 1:
                        Product p = getProdDetails();
                        db.Products.Add(p);
                        db.SaveChanges();
                        break;
                    case 2:
                        Console.WriteLine("1 Specific record 2 ALL records");
                        int ch = int.Parse(Console.ReadLine());
                        if(ch==1)
                        {
                            Console.WriteLine("Enter the id which you want to search");
                            id = int.Parse(Console.ReadLine());
                            List<Product> plist = db.SELECTPROD(id).ToList<Product>();
                            if (plist.Count==0)
                            {
                                Console.WriteLine("Not valid");
                                break;
                            }
                            else
                            {
                                Console.WriteLine("PID\tPNAME\tCID\tBATCHID\tCATEGORY");
                                Console.WriteLine("________________________________");
                                foreach (Product p1 in db.SELECTPROD(id))
                                {
                                    display(p1);
                                }
                            }                           
                        }
                        else if(ch==2)
                        {
                            Console.WriteLine("PID\tPNAME\tCID\tBATCHID\tCATEGORY");
                            Console.WriteLine("________________________________");
                            foreach(Product p1 in db.selectalldata())
                            {
                                display(p1);
                            }
                        }
                        else
                            Console.WriteLine("Invalid choice");

                        break;
                    case 3:
                        Console.WriteLine("UPDATE THE RECORD");
                        Console.WriteLine("ENTER THE ID = ");
                        id = Convert.ToInt32(Console.ReadLine());
                        prod = db.Products.Find(id);
                        if (prod == null)
                            Console.WriteLine("Product with specifie id does not exist");
                        else
                        {
                            Console.Write("\nEnter PNAME = ");
                            prod.Pname = Console.ReadLine();
                            Console.Write("\nEnter CID = ");
                            prod.Cid = Convert.ToInt32(Console.ReadLine());
                            Console.Write("\nEnter BATCHID = ");
                            prod.batchId = Convert.ToInt32(Console.ReadLine());
                            db.SaveChanges();
                        }
                        break;
                    case 4:
                        Console.WriteLine("DELETE THE RECORD");
                        Console.WriteLine("ENTER THE ID = ");
                        id = Convert.ToInt32(Console.ReadLine());
                        prod = db.Products.Find(id);
                        if (prod == null)
                            Console.WriteLine("Product with specifie id does not exist");
                        else
                        {
                            db.Products.Remove(prod);
                            db.SaveChanges();
                        }
                        break;
                    case 5:
                        break;
                    default: Console.WriteLine("Invalid choice ");break;
                }
            } while (choice != 5);

        }
    }
}
